package negocios;

import java.time.*;
import beans.Cliente;
import beans.Fornecedor;
import beans.Funcionario;
import beans.MateriaPrima;
import beans.Produto;

public class PanelaFit {
	private ControladorClientes clientes;
	private ControladorFornecedores fornecedores;
	private ControladorFuncionarios funcionarios;
	private ControladorMateriaPrimas materiaPrimas;
	private ControladorProdutos produtos;
	
	private static PanelaFit instance;
	
	private PanelaFit(){
		this.clientes = new ControladorClientes();
		this.fornecedores = new ControladorFornecedores();
		this.funcionarios = new ControladorFuncionarios();
		this.materiaPrimas = new ControladorMateriaPrimas();
		this.produtos = new ControladorProdutos();
	}
	
	private static PanelaFit getInstance(){
		if(instance == null){
			instance = new PanelaFit();
		}
		return instance;
	}
	
	public void cadastrarCliente(Cliente c){
		clientes.cadastrar(c);
	}
	
	public void removerCliente(int codigo){
		clientes.remover(codigo);
	}
	
	public Cliente buscarCliente(int codigo){
		return clientes.buscar(codigo);
	}
	
	public boolean alterarCliente(Cliente novoCliente){
		return clientes.alterar(novoCliente);
	}
	
	public void cadastrarFornecedor(Fornecedor f){
		fornecedores.cadastrar(f);
	}
	
	public void removerFornecedor(int codigo){
		fornecedores.remover(codigo);
	}
	
	public Fornecedor buscarFornecedor(int codigo){
		return fornecedores.buscar(codigo);
	}
	
	public boolean alterarFornecedor(Fornecedor novoFornecedor){
		return fornecedores.alterar(novoFornecedor);
	}
	
	public String getTelefoneFornecedor(int codigo){
		return fornecedores.getTelefone(codigo);
	}
	
	public void cadastrarFuncionario(Funcionario f){
		funcionarios.cadastrar(f);
	}
	
	public void removerFuncionario(int codigo){
		funcionarios.remover(codigo);
	}
	
	public Funcionario buscarFuncionario(int codigo){
		return funcionarios.buscar(codigo);
	}
	
	public boolean alterarFuncionario(Funcionario novoFuncionario){
		return funcionarios.alterar(novoFuncionario);
	}
	
	public int getNivelFuncionario(int codigo){
		return funcionarios.getNivel(codigo);
	}
	
	public void cadastrarMateriaPrima(MateriaPrima m){
		materiaPrimas.cadastrar(m);
	}
	
	public void removerMateriaPrima(int codigo){
		materiaPrimas.remover(codigo);
	}
	
	public MateriaPrima buscarMateriaPrima(int codigo){
		return materiaPrimas.buscar(codigo);
	}
	
	public boolean alterarMateriaPrima(MateriaPrima novaMateriaPrima){
		return materiaPrimas.alterar(novaMateriaPrima);
	}
	
	public int getQuantidadeMateriaPrima(int codigo){
		return materiaPrimas.getQuantidade(codigo);
	}
	
	public void cadastrarProduto(Produto p){
		produtos.cadastrar(p);
	}
	
	public void removerProduto(int codigo){
		produtos.remover(codigo);
	}
	
	public Produto buscarProduto(int codigo){
		return produtos.buscar(codigo);
	}
	
	public boolean alterarProdutos(Produto novoProduto){
		return produtos.alterar(novoProduto);
	}
	
	public LocalDate getDataFabricacao(int codigo){
		return produtos.getDataFabricacao(codigo);
	}
	
	public LocalDate getDataValidade(int codigo){
		return produtos.getDataValidade(codigo);
	}
}
