package negocios;

import beans.Produto;
import dados.RepositorioProduto;
import java.time.*;

public class ControladorProdutos {
	private RepositorioProduto repositorio;
	
	public ControladorProdutos(){
		this.repositorio = RepositorioProduto.getInstance();
	}


	public void cadastrar(Produto p){
		if(p==null){
			throw new IllegalArgumentException("Cliente inválido");
		}
		else{
			if(p.getCodigo()!=0){
				this.repositorio.cadastrarProduto(p);
			}
		}
	}
	
	public Produto buscar(int codigo){
		return this.repositorio.buscarProduto(codigo);
	}
	
	public void remover(int codigo){
		this.repositorio.removerProduto(codigo);
	}
	
	public boolean alterar(Produto novoProduto){
		boolean igual = false;
		if(novoProduto!=null){
			this.repositorio.alterarProduto(novoProduto);
			igual=true;
		}
		return igual;
	}
	public LocalDate getDataFabricacao(int codigo){
		Produto p = this.repositorio.buscarProduto(codigo);
		return p.getDataFabricacao();
	}
	
	public LocalDate getDataValidade(int codigo){
		Produto p = this.repositorio.buscarProduto(codigo);
		return p.getDataValidade();//retornando apenas a data de validade
	}
}