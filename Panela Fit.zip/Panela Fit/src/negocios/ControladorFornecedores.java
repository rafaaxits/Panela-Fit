package negocios;

import beans.Fornecedor;
import dados.RepositorioFornecedor;

public class ControladorFornecedores {
	private RepositorioFornecedor repositorio;
	
	public ControladorFornecedores() {
		this.repositorio = RepositorioFornecedor.getInstance();
	}
	
	public void cadastrar(Fornecedor f) {
		if(f == null) {
			throw new IllegalArgumentException("Fornecedor inválido!");
		} else {
			if(f.getCodigo() != 0) {
				this.repositorio.cadastrarFornecedor(f);
			}
		}
	}
	
	public Fornecedor buscar(int codigo) {
		return this.repositorio.buscarFornecedor(codigo);
	}
	
	public void remover(int codigo) {
		this.repositorio.removerFornecedor(codigo);
	}
	
	public boolean alterar(Fornecedor novoFornecedor) {
		boolean igual = false;
		if(novoFornecedor != null) {
			this.repositorio.alterarFornecedor(novoFornecedor);
			igual = true;
		}
		return igual;
	}
	
	public String getTelefone(int codigo){
		Fornecedor f = this.repositorio.buscarFornecedor(codigo);
		return f.getTelefone();
	}
}