package negocios;

import beans.MateriaPrima;
import dados.RepositorioMateriaPrima;

public class ControladorMateriaPrimas {
	private RepositorioMateriaPrima repositorio;
	
	public ControladorMateriaPrimas(){
		this.repositorio = RepositorioMateriaPrima.getInstance();
	}
	
	public void cadastrar (MateriaPrima m){
		if(m==null){
			throw new IllegalArgumentException("Cliente inválido");
		}
		else{
			if(m.getCodigo()!=0){
				this.repositorio.cadastrarMateriaPrima(m);
			}
		}
	}
	public MateriaPrima buscar(int codigo){
		return this.repositorio.buscarMateriaPrima(codigo);
	}
	
	public void remover(int codigo){
		this.repositorio.removerMateriaPrima(codigo);
	}
	
	public boolean alterar(MateriaPrima novaMateriaPrima){
		boolean igual = false;
		if(novaMateriaPrima!=null){
			this.repositorio.alterarMateriaPrima(novaMateriaPrima);
			igual = true;
		}
		return igual;
	}
	public int getQuantidade(int codigo){
		MateriaPrima m = this.repositorio.buscarMateriaPrima(codigo);
		return m.getQuantidade();
	}
}
