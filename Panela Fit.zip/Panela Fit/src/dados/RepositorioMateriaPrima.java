package dados;

import java.util.ArrayList;

import beans.MateriaPrima;

public class RepositorioMateriaPrima {
	private ArrayList<MateriaPrima> listaMateriasPrimas = new ArrayList<MateriaPrima>();
	private static RepositorioMateriaPrima instance;
	
	public static RepositorioMateriaPrima getInstance(){
		if(instance == null){
			instance = new RepositorioMateriaPrima();
		}
		return instance;
	}
	
	public ArrayList<MateriaPrima> getListaMateriasPrimas() {
		return listaMateriasPrimas;
	}

	public void setListaMateriasPrimas(ArrayList<MateriaPrima> listaMateriasPrimas) {
		this.listaMateriasPrimas = listaMateriasPrimas;
	}

	public boolean cadastrarMateriaPrima(MateriaPrima materiaprima){
		boolean igual = false;
		if(materiaprima!=null){
			if((listaMateriasPrimas.contains(materiaprima))){
				return igual;
			}
			else{
				listaMateriasPrimas.add(materiaprima);
				igual=true;
			}
		}
		return igual;
	}
	
	public boolean alterarMateriaPrima(MateriaPrima novaMateriaPrima) {
		boolean igual = false;
		if (novaMateriaPrima != null) {
			for(int i = 0; i < listaMateriasPrimas.size(); i++) {
				if(novaMateriaPrima.getCodigo() == listaMateriasPrimas.get(i).getCodigo()) {
					listaMateriasPrimas.remove(i);
					listaMateriasPrimas.add(novaMateriaPrima);
					igual = true;
				}
			}
		}
		return igual;
	}
	
	public MateriaPrima buscarMateriaPrima(int codigo) {
		for(MateriaPrima materiaprima : listaMateriasPrimas) {
			if(materiaprima.getCodigo() == codigo) {
				return materiaprima;
			}
		}
		return null;
	}
	
	public boolean removerMateriaPrima(int codigo) {
		boolean igual = false;
			for(int i=0;i<listaMateriasPrimas.size();i++){
				if(listaMateriasPrimas.get(i).getCodigo() == codigo){
					listaMateriasPrimas.remove(i);
						igual = true;
			}
		}
		return igual;
	}
	
	@Override
	public String toString() {
		return "RepositorioMateriaPrima [listaMateriasPrimas = " + listaMateriasPrimas + "]";
			
	}
}