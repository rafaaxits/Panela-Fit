package dados;
import beans.Fornecedor;
public interface IRepositorioFornecedor {
	public boolean cadastrarFornecedor(Fornecedor fornecedor);
	public boolean alterarFornecedor(Fornecedor novoFornecedor);
	public Fornecedor buscarFornecedor(int codigo);
	public boolean removerFornecedor(int codigo);
}
