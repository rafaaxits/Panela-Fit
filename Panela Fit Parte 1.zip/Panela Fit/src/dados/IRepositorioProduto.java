package dados;
import beans.Produto;
public interface IRepositorioProduto {
	public boolean cadastrarProduto(Produto produto);
	public boolean alterarProduto(Produto novoProduto);
	public Produto buscarProduto(int codigo);
	public boolean removerProduto(int codigo);
}
