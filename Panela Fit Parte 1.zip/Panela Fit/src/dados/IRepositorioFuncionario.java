package dados;
import beans.Funcionario;
public interface IRepositorioFuncionario {
	public boolean cadastrarFuncionario(Funcionario funcionario);
	public boolean alterarFuncionario(Funcionario novoFuncionario);
	public Funcionario buscarFuncionario(int codigo);
	public boolean removerFuncionario(int codigo);
}
